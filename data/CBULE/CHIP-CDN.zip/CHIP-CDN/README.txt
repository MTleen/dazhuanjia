1. Mainfest:
* 国际疾病分类ICD-10北京临床版v601.xlsx:  诊断词候选集答案
* CHIP-CDN_train.json: 训练集 
* CHIP-CDN_dev.json: 验证集
* CHIP-CDN_test.json: 测试集, 选手提交的时候需要为每条记录增加“normalized_result”字段, 如有多个预测值，请用“##”分隔。
* example_gold.json: 标准答案示例
* example_pred.json: 提交结果示例
* README.txt: 说明文件


2. 该任务提交的文件名为：CHIP-CDN_test.json


